Grant Li - 1012558982

Included files:

OACP.c
readme.txt
Design_Document.pdf

Instructions to run the OACP:

1. open the terminal in this directory
2. let exeName represent the name of the executable you want create from the OACP.c file
3. type "gcc -o exeName OACP.c" and press enter
4. type "./exeName" and press enter
5. type each individual permission using either 'y' or 'n' for yes or no respectively
6. press enter after typing a permission
7. OACP permission information will be outputted after all input is given